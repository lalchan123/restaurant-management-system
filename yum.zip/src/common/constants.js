export const currentCurrency = "$";
